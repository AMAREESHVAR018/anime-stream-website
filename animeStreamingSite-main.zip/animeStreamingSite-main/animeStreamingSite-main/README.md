# animeStreamingSite
This website is a dummy anime streaming site with a navigation panel, search bar and cards representing what kind of anime you want to watch. The website was designed to emulate a real-life anime streaming site. I created it to the best of my abilities. This website is made completely of HTML, CSS and Bootstrap. 
